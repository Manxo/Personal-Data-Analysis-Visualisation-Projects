# The Prosper Loan Data Analysis
## by Yahaya Yusuf Danladi


## Dataset
This data set contains 113,937 loans with 81 variables on each loan, including loan amount, borrower rate (or interest rate), current loan status, borrower income, and many others. Most of the loans originated between December 2014 and November 2015.
[here](https://s3.amazonaws.com/udacity-hosted-downloads/ud651/prosperLoanData.csv) and the Dictionary definations [here](https://docs.google.com/spreadsheets/d/1gDyi_L4UvIrLTEC6Wri5nbaMmkGmLQBk-Yx3z0XDEtI/edit#gid=0).


## Summary of Findings
Wrangling the data we found some issues with the data i.e.:

    There alot of missing values especially in "CreditGrade" column.
    Some columns name aren't proper e.g "ProsperRating (numeric)".
    Inconsistent data in the "DateCreditPulled" column.
    Date column are not in datetime format.

Then we Clean-up by:

    Load only columns necessary for this analysis to a new dataframe called "df".
    Drop rows with missing values and columns with inconsistent data.
    Change date column to appropriate type (datetime).

We worked with the IsBorrowerHomeowner, EmploymentStatus, ProsperRatingNumeric, LoanOriginalAmount,and Recommendations colums as features of interest. We found out that majority of the borrowers in the Prosper loan system are also homeowners, 86% percent of the borrower are employed, most (99%) of the investments came from non-friends, and 22% of borrowers are on the 4.0 risk score. Also, majority of borrowers borrow loans of about 4,000 dollars only with very few who borrow above 15,000 dollars. Many of the loans attract 31% interest rate, and recommend didn play much role in qualifying for loan as 98% (75,196) of the borrowers do not have any recommendations.

We can see some positive correlation between the Prosper rating and the loan amount given to borrowers, and a weak negative correlation between the Loan amount and the recommendations, we see majority of the borrowers got large amount of loans with little or no recommendations the we observed that the same loan Amount is given to borrowers regardless whether they own a home or not. Investigating the relations between the recommendations and Prosper rating, there is no correlations between Prosper score and recommendations.

Generally, borrowers that have some source of income or employment and are also homeowners have better ratings, hence we can say a borrowers employment status affect their rating.


## Key Insights for Presentation

Some key Insights we shall consider for Presentations are:
1. Borrowers can access any loan amount regardless they own a home or not.
2. Recommendations have no Influence in qualifying for loan.
3. Borrowers that are employed and are also homeowners have better prosper ratings


## Reference
    https://www.prosper.com/
    https://www.investopedia.com/prosper-personal-loans-review-4843741
    https://www.lawinsider.com/dictionary/loan-listing.
    https://www.prosper.com/invest/how-to-invest/prosper-ratings/?mod=article_inline

